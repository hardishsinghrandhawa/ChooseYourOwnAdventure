import sys
import random
import time


def type(text):
    wait = 0
    for c in text:
        sys.stdout.write(c)
        time.sleep(random.randrange(5, 10)/200.0)

def ship():
    type("As a true captain, you stay loyal to your ship and go down under the waves. Was it worth it?\n"
         "Game Over!")
    quit()


def swim():
    type("You jump off the ship as it splits into pieces. A narrow escape! However, your troubles are not over.\n"
              "There is a raging storm around you! You swim back towards the shore. However, you lose strength and \n"
              "become unconsious...")

    type("You wake up and feel pain all over your body. You are hungry and weak. You look around and see that you are\n"
         "on an island. In front of you are two choices of food...")

    print("What food would you like to try to eat?")

    print("1. boar   2. berries ")

    question = input("Choose 1 or 2: ")

    if question == 1:
        boar()

    elif question == 2:
        berries()


def helicopter():
    type("You run to your helicopter at the top of the ship. It is wet and in bad shape due to the storm.\n "
              "You go inside anyways. As you begin to liftoff, you feel something is not quite right. The propellers \n"
              "are unable to move due to the harsh winds! The winds push you in your helicopter into the sea. Your \n"
              "only choice now is to swim...")

    type("There is a raging storm around you! You swim back towards the shore. However, you lose strength and\n"
              "become unconsious...")


    type("You wake up and feel pain all over your body. You are hungry and weak. You look around and see that you are\n"
         "on an island. In front of you are two choices of food...")

    print("What food would you like to try to eat?")

    print("1. boar   2. berries ")

    question = input("Choose 1 or 2: ")

    if question == 1:
        boar()

    elif question == 2:
        berries()


def boar():
    type("You see a boar with its back towards you. Perfect! You slowly creep towards it. However, you do not have a\n"
         "weapon or any strength to make one. The boar turns around, sees you, and runs away.\n")
    type("Now you are very hungry and weak. You are not sure if you will make it. You walk into the forest and\n"
         "you see something shining. It's a golden bowl with so much food inside! Your mouth waters. You don't\n"
         "know whose it might be. What will you do? ")
    print("Would you like to eat the food?")
    print("1. yes  	2. no ")
    question2 = input("Choose 1 or 2: ")

    if question2 == 1:
        yes()

    elif question2 == 2:
        no()


def berries():
    type("You see berries in a bush nearby. Your lucky day! However, you forget that some berries can be poisonous.\n"
         "Unfortunately, these were. Game Over!")
    quit()


def yes():
    type("You walk towards the food. You see a nice juicy fruit to eat. You pick it up and hear rumbing under your feet\n"
         "It's a trap! You fall into a pit with spikes. The spikes pierce your body. The last thing you see as you look up\n"
         "is... a monkey? Game Over!")
    quit()


def no():
    type("You don't go for the food. You fear it is a trap. Suddenly, you feel a tap on your shoulder. You look behind you.\n"
         "It's a .. monkey. The monkey is huge and can speak human. It says that the food is a trap and that you are smart\n"
         "to let it be. It requests to lead you to its base.\n ")
    print("Would you like to enter?")
    print(" 1. yes  2. no")
    question3 = input("Choose 1 or 2:")

    if question3 == 1:
        yes2()

    elif question3 == 2:
        no2()


def yes2():
    type("You enter the base. There you see many luxurious items such as gold, diamonds, many vehicles, etc. The monkey gives you\n "
    "some fruit. You wonder how the monkey got all this stuff. It says that since you are not greedy as everyone else that comes on the\n"
    "island, and it will let you keep one of its gold helicopters. You are in awe. The next day you set off for home, happier and\n"
    "richer than before. The End! :)")


def no2():
    type("The monkey does not like people rejecting his offers. He picks you up and throws you off the island. Game Over!")


def main():
    type("Shipwrek")
    type("\nYou are a captain on your great ship, the Storm Survivor. It is a stormy night and you are worried\n"
          "that your ship might capsize soon due to the giant waves. You barely get some sleep when you hear\n"
          "cracking from under your feet. In an ironic twist of fate, the Storm Survivor succumbs to the storm.\n"
          "The ship is sinking! There are two choices you have to try and save your life. Choose wisely...")

    type("\n\nWhat is your choice?")

    type("\n 1. go down with the ship  	2. try to swim to shore  	3. use your helicopter")

    choice = input("\nMake your choice: ")
    if choice == 1:
        ship()
    elif choice == 2:
        swim()
    else:
        helicopter()


main()